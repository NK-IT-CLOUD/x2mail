OC.L10N.register(
    "x2mail",
    {
    "Email" : "البريد الإلكترونى",
    "Error" : "خطأ",
    "Users will login manually, or define credentials in their personal settings for automatic logins." : "المستخدمين س يدخلو يدويا، او تعريف شهادات في اعدادات حساباتهم الشخصية لتسجيل الدخول آليا.",
    "Attempt to automatically login users with their Nextcloud username and password, or user-defined credentials, if set." : "حاول ان تقوم بتسجيل دخول المستخدمين مع اسم المستخدم و الرمز لنيكست كلاود، او شهادة تعريف المستخدم، اذا تناسب.",
    "Attempt to automatically login users with their Nextcloud email and password, or user-defined credentials, if set." : "حاول ان تقوم بتسجيل دخول المستخدمين مع الايميل و الرمز لنيكست كلاود، او شهادة تعريف المستخدم، اذا تناسب.",
    "Save" : "حفظ",
    "may have some" : "هل لي بعض",
    "security considerations" : "اعتبارات امنية",
    "Password" : "كلمة السر"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
