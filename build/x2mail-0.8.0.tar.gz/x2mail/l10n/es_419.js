OC.L10N.register(
    "x2mail",
    {
    "Email" : "Correo electrónico",
    "Error" : "Error",
    "Save" : "Guardar",
    "Password" : "Contraseña"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
