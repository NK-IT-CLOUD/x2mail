OC.L10N.register(
    "x2mail",
    {
    "Email" : "Postel",
    "Error" : "Fazi",
    "Invalid argument(s)" : "Arguzenn(où) fall",
    "Saved successfully" : "Enrollet mat",
    "Users will login manually, or define credentials in their personal settings for automatic logins." : "An implijourienn a zeuio tre gant an dorn, pe lakaet a vo gante ho tirouroù identitelez en ho arventennoù bersonnel evit ur mont-tre otomatek. ",
    "Attempt to automatically login users with their Nextcloud username and password, or user-defined credentials, if set." : "Klaskit em-gevreañ gant hoc'h anv-implijader hag ho ker-tremen Nextcloud, pe ar c'hredadoù termenet gant an implijader, m'emaint termenet.",
    "Attempt to automatically login users with their Nextcloud email and password, or user-defined credentials, if set." : "Klaskit em-gevreañ gant ho postel hag ho ker-tremen Nextcloud, pe ar c'hredadoù termenet gant an implijader, m'emaint termenet.",
    "Save" : "Enrollañ",
    "may have some" : "en deus un tamm marteze",
    "security considerations" : "preder surentez",
    "Password" : "Ger-tremen"
},
"nplurals=5; plural=((n%10 == 1) && (n%100 != 11) && (n%100 !=71) && (n%100 !=91) ? 0 :(n%10 == 2) && (n%100 != 12) && (n%100 !=72) && (n%100 !=92) ? 1 :(n%10 ==3 || n%10==4 || n%10==9) && (n%100 < 10 || n% 100 > 19) && (n%100 < 70 || n%100 > 79) && (n%100 < 90 || n%100 > 99) ? 2 :(n != 0 && n % 1000000 == 0) ? 3 : 4);");
