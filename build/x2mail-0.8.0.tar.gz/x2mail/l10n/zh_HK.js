OC.L10N.register(
    "x2mail",
    {
    "Email" : "電郵地址",
    "Error" : "錯誤",
    "Invalid argument(s)" : "無效的參數",
    "Saved successfully" : "保存成功",
    "Users will login manually, or define credentials in their personal settings for automatic logins." : "用戶將手動登入，或在其個人設置中定義身分驗證以自動登入。",
    "Attempt to automatically login users with their Nextcloud username and password, or user-defined credentials, if set." : "嘗試使用其Nextcloud用戶名和密碼或用戶定義的身分驗證（如果設置）自動登入用戶。",
    "Attempt to automatically login users with their Nextcloud email and password, or user-defined credentials, if set." : "嘗試使用其Nextcloud電子郵件和密碼或用戶定義的身分驗證（如果設置）自動登入用戶。",
    "Save" : "儲存",
    "may have some" : "可能有一些",
    "security considerations" : "安全考慮",
    "Password" : "密碼"
},
"nplurals=1; plural=0;");
