OC.L10N.register(
    "x2mail",
    {
    "Email" : "Ел.пошта",
    "Error" : "Помилка",
    "Invalid argument(s)" : "Недопустимий аргумент(и)",
    "Saved successfully" : "Збережено успішно",
    "Users will login manually, or define credentials in their personal settings for automatic logins." : "Користувачі будуть входити в систему вручну або визначати облікові дані в особистих налаштуваннях для автоматичного входу. ",
    "Attempt to automatically login users with their Nextcloud username and password, or user-defined credentials, if set." : "Спроба автоматичного входу користувачів за допомогою їхнього імені користувача та пароля Nextcloud або визначених користувачем облікових даних, якщо вони встановлені. ",
    "Attempt to automatically login users with their Nextcloud email and password, or user-defined credentials, if set." : "Спроба автоматичного входу користувачів за допомогою їхньої електронної пошти та пароля Nextcloud або визначених користувачем облікових даних, якщо вони встановлені. ",
    "Save" : "Зберегти",
    "may have some" : "може мати деякі",
    "security considerations" : "проблеми з безпекою",
    "Password" : "Пароль"
},
"nplurals=4; plural=(n % 1 == 0 && n % 10 == 1 && n % 100 != 11 ? 0 : n % 1 == 0 && n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 1 : n % 1 == 0 && (n % 10 ==0 || (n % 10 >=5 && n % 10 <=9) || (n % 100 >=11 && n % 100 <=14 )) ? 2: 3);");
