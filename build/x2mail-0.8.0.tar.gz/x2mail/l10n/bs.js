OC.L10N.register(
    "x2mail",
    {
    "Email" : "E-pošta",
    "Error" : "Greška",
    "Save" : "Spremi",
    "Password" : "Lozinka"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
