OC.L10N.register(
    "x2mail",
    {
    "Email" : "អ៊ីមែល",
    "Error" : "កំហុស",
    "Save" : "រក្សាទុក",
    "Password" : "ពាក្យសម្ងាត់"
},
"nplurals=1; plural=0;");
