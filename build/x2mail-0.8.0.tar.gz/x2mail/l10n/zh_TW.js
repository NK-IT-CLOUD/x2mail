OC.L10N.register(
    "x2mail",
    {
    "Email" : "電子郵件",
    "Error" : "錯誤",
    "Invalid argument(s)" : "無效的參數",
    "Saved successfully" : "已成功儲存",
    "Users will login manually, or define credentials in their personal settings for automatic logins." : "使用者將手動登入，或在其個人設定中定義憑證以自動登入。",
    "Attempt to automatically login users with their Nextcloud username and password, or user-defined credentials, if set." : "嘗試使用其 Nextcloud 使用者名和密碼或使用者定義的身分驗證（如果設定）自動登入使用者。",
    "Attempt to automatically login users with their Nextcloud email and password, or user-defined credentials, if set." : "嘗試使用其 Nextcloud 電子郵件和密碼或使用者定義的憑證（如果設定）自動登入使用者。",
    "Save" : "儲存",
    "may have some" : "可能有一些",
    "security considerations" : "安全考量",
    "Password" : "密碼"
},
"nplurals=1; plural=0;");
