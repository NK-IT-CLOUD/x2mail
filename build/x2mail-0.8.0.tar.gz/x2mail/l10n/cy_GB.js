OC.L10N.register(
    "x2mail",
    {
    "Email" : "E-bost",
    "Error" : "Gwall",
    "Save" : "Cadw",
    "Password" : "Cyfrinair"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
