OC.L10N.register(
    "x2mail",
    {
    "Email" : "E-mail",
    "Error" : "Erreur",
    "Invalid argument(s)" : "Argument(s) non valides",
    "Saved successfully" : "Enregistré avec succès",
    "Users will login manually, or define credentials in their personal settings for automatic logins." : "Les utilisateurs se connecteront manuellement ou définiront des informations d'identification dans leurs paramètres personnels pour les connexions automatiques.",
    "Attempt to automatically login users with their Nextcloud username and password, or user-defined credentials, if set." : "Tenter de connecter automatiquement les utilisateurs avec leur nom d'utilisateur et mot de passe Nextcloud, ou avec les informations d'identification définies par l'utilisateur, si elles le sont.",
    "Attempt to automatically login users with their Nextcloud email and password, or user-defined credentials, if set." : "Tenter de connecter es utilisateurs avec leur e-mail et mot de passe Nextcloud, ou avec informations d'identification définies par l'utilisateur, si définies.",
    "Save" : "Enregistrer",
    "may have some" : "peut avoir",
    "security considerations" : "Motifs de sécurité",
    "Password" : "Mot de passe"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
