OC.L10N.register(
    "x2mail",
    {
    "Email" : "Ηλ.Ταχυδρομείο",
    "Error" : "Σφάλμα",
    "Invalid argument(s)" : "Μη έγκυρο όρισμα(τα)",
    "Saved successfully" : "Επιτυχής αποθήκευση",
    "Users will login manually, or define credentials in their personal settings for automatic logins." : "Οι χρήστες θα συνδεθούν χειροκίνητα ή θα ορίσουν διαπιστευτήρια στις προσωπικές τους ρυθμίσεις για αυτόματη σύνδεση.",
    "Attempt to automatically login users with their Nextcloud username and password, or user-defined credentials, if set." : "Αυτόματη σύνδεση χρηστών με όνομα χρήστη και κωδικό πρόσβασης του Nextcloud ή με τα διαπιστευτήρια που καθορίζονται από τον χρήστη.",
    "Attempt to automatically login users with their Nextcloud email and password, or user-defined credentials, if set." : "Αυτόματη σύνδεση χρηστών με την διεύθυνση Ηλ.Ταχυδρομείου και κωδικό πρόσβασης του Nextcloud ή με τα διαπιστευτήρια που καθορίζονται από τον χρήστη.",
    "Save" : "Αποθήκευση",
    "may have some" : "μπορεί να έχει κάποια",
    "security considerations" : "θέματα ασφάλειας",
    "Password" : "Συνθηματικό"
},
"nplurals=2; plural=(n != 1);");
