OC.L10N.register(
    "x2mail",
    {
    "Email" : "El. paštas",
    "Error" : "Klaida",
    "Saved successfully" : "Sėkmingai įrašyta",
    "Save" : "Įrašyti",
    "Password" : "Slaptažodis"
},
"nplurals=4; plural=(n % 10 == 1 && (n % 100 > 19 || n % 100 < 11) ? 0 : (n % 10 >= 2 && n % 10 <=9) && (n % 100 > 19 || n % 100 < 11) ? 1 : n % 1 != 0 ? 2: 3);");
