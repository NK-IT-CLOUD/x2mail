OC.L10N.register(
    "x2mail",
    {
    "Email" : "E-mail",
    "Error" : "Błąd",
    "Invalid argument(s)" : "Nieprawidłowe argumenty",
    "Saved successfully" : "Zapisano pomyślnie",
    "Users will login manually, or define credentials in their personal settings for automatic logins." : "Użytkownicy zalogują się ręcznie lub zdefiniują poświadczenia w swoich ustawieniach osobistych w celu automatycznego logowania.",
    "Attempt to automatically login users with their Nextcloud username and password, or user-defined credentials, if set." : "Próba automatycznego logowania użytkowników przy użyciu nazwy użytkownika i hasła Nextcloud lub poświadczeń zdefiniowanych przez użytkownika, jeśli są ustawione.",
    "Attempt to automatically login users with their Nextcloud email and password, or user-defined credentials, if set." : "Próba automatycznego logowania użytkowników przy użyciu adresu e-mail i hasła Nextcloud lub poświadczeń zdefiniowanych przez użytkownika, jeśli są ustawione.",
    "Save" : "Zapisz",
    "may have some" : "może mieć pewne",
    "security considerations" : "względy bezpieczeństwa",
    "Password" : "Hasło",
    "Don't fully integrate in Nextcloud, use in iframe" : "Nie integruj całkowicie z Nextcloudem, używaj wewnątrz iframe",
    "Debug" : "Debuguj"
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");
