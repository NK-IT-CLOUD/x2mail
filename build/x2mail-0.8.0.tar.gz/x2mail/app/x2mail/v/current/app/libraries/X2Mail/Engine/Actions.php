<?php

namespace X2Mail\Engine;

use X2Mail\Engine\Enumerations\Capa;

class Actions
{
	use Actions\User;
	use Actions\UserAuth;
	use Actions\Raw;
	use Actions\Response;
	use Actions\Localization;
	use Actions\Themes;

	use \X2Mail\Mail\Log\Inherit;

	const AUTH_MAILTO_TOKEN_KEY = 'x2mmailtoauth';

	/**
	 * This session cookie contains a \X2Mail\Engine\Model\Account
	 * Value is Base64 EncryptToJSON
	 */
	const AUTH_SPEC_TOKEN_KEY = 'x2maccount';

	/**
	 * This session cookie optionally contains a \X2Mail\Engine\Model\AdditionalAccount
	 * Value is Base64 EncryptToJSON
	 */
	const AUTH_ADDITIONAL_TOKEN_KEY = 'x2madditional';

	const APP_DUMMY = '********';

	/**
	 * @var \X2Mail\Mail\Base\Http
	 */
	protected $oHttp = null;

	/**
	 * @var array
	 */
	protected $aCurrentActionParams = array();

	/**
	 * @var \X2Mail\Mail\Client\MailClient
	 */
	protected $oMailClient = null;

	/**
	 * @var \X2Mail\Engine\Plugins\Manager
	 */
	protected $oPlugins = null;

	/**
	 * @var \X2Mail\Mail\Log\Logger
	 */
	protected $oLoggerAuth;

	/**
	 * @var array of \X2Mail\Mail\Cache\CacheClient
	 */
	protected $aCachers = array();

	/**
	 * @var \X2Mail\Engine\Providers\Storage
	 */
	protected $oStorageProvider = null;

	/**
	 * @var \X2Mail\Engine\Providers\Storage
	 */
	protected $oLocalStorageProvider = null;

	/**
	 * @var \X2Mail\Engine\Providers\Files
	 */
	protected $oFilesProvider = null;

	/**
	 * @var \X2Mail\Engine\Providers\Domain
	 */
	protected $oDomainProvider = null;

	/**
	 * @var \X2Mail\Engine\Providers\Settings
	 */
	protected $oSettingsProvider = null;

	/**
	 * @var \X2Mail\Engine\Providers\Settings
	 */
	protected $oLocalSettingsProvider = null;

	/**
	 * @var \X2Mail\Engine\Config\Application
	 */
	protected $oConfig = null;

	/**
	 * @var bool
	 */
	protected $bIsJson = false;

	function __construct()
	{
		$this->oConfig = Api::Config();

		$this->oLogger = Api::Logger();
		if ($this->oConfig->Get('logs', 'enable', false) || $this->oConfig->Get('debug', 'enable', false)) {

			$oDriver = null;
			$sLogFileName = $this->oConfig->Get('logs', 'filename', '');
			if ('syslog' === $sLogFileName) {
				$oDriver = new \X2Mail\Mail\Log\Drivers\Syslog();
			} else if ('stderr' === $sLogFileName) {
				$oDriver = new \X2Mail\Mail\Log\Drivers\StderrStream();
			} else {
				$sLogFileFullPath = \trim($this->oConfig->Get('logs', 'path', '')) ?: \APP_PRIVATE_DATA . 'logs';
				\is_dir($sLogFileFullPath) || \mkdir($sLogFileFullPath, 0700, true);
				$oDriver = new \X2Mail\Mail\Log\Drivers\File($sLogFileFullPath . '/' . $this->compileLogFileName($sLogFileName));
			}
			$this->oLogger->append($oDriver
				->SetTimeZone($this->oConfig->Get('logs', 'time_zone', 'UTC'))
			);

			$oHttp = $this->Http();

			$this->logWrite(
				'[SM:' . APP_VERSION . '][IP:'
				. $oHttp->GetClientIp($this->oConfig->Get('labs', 'http_client_ip_check_proxy', false))
				. '][PID:' . (\X2Mail\Mail\Base\Utils::FunctionCallable('getmypid') ? \getmypid() : 'unknown')
				. '][' . \X2Mail\Mail\Base\Http::GetServer('SERVER_SOFTWARE', '~')
				. '][' . \PHP_SAPI
				. '][Streams:' . \implode(',', \stream_get_transports())
				. '][' . $oHttp->GetMethod() . ' ' . $oHttp->GetScheme() . '://' . $oHttp->GetHost(false) . \X2Mail\Mail\Base\Http::GetServer('REQUEST_URI', '') . ']'
			);
		}

		$this->oPlugins = new Plugins\Manager($this);
		$this->oPlugins->RunHook('filter.application-config', array($this->oConfig));
	}

	public function SetIsJson(bool $bIsJson): self
	{
		$this->bIsJson = $bIsJson;

		return $this;
	}

	public function GetIsJson(): bool
	{
		return $this->bIsJson;
	}

	public function Config(): Config\Application
	{
		return $this->oConfig;
	}

	/**
	 * @return mixed
	 */
	protected function fabrica(string $sName, ?Model\Account $oAccount = null)
	{
		$mResult = null;
		$this->oPlugins->RunHook('main.fabrica', array($sName, &$mResult), false);

		if (null === $mResult) {
			switch ($sName) {
				case 'files':
					// X2Mail\Engine\Providers\Files\IFiles
					$mResult = new Providers\Files\FileStorage(APP_PRIVATE_DATA . 'storage');
					break;
				case 'storage':
				case 'storage-local':
					// X2Mail\Engine\Providers\Storage\IStorage
					$mResult = new Providers\Storage\FileStorage(
						APP_PRIVATE_DATA . 'storage', 'storage-local' === $sName);
					break;
				case 'settings':
					// X2Mail\Engine\Providers\Settings\ISettings
					$mResult = new Providers\Settings\DefaultSettings($this->StorageProvider());
					break;
				case 'settings-local':
					// X2Mail\Engine\Providers\Settings\ISettings
					$mResult = new Providers\Settings\DefaultSettings($this->LocalStorageProvider());
					break;
				case 'domain':
					// Providers\Domain\DomainInterface
					$mResult = new Providers\Domain\DefaultDomain(APP_PRIVATE_DATA . 'domains', $this->Cacher());
					break;
				case 'filters':
					// Providers\Filters\FiltersInterface
					$mResult = new Providers\Filters\SieveStorage(
						$this->oPlugins, $this->oConfig
					);
					break;
				case 'address-book':
					// NC plugin overrides via main.fabrica hook -> NextcloudAddressBook
					// No standalone fallback — X2Mail requires Nextcloud
					break;
				case 'identities':
				case 'suggestions':
					$mResult = [];
					break;
/*				// See function Cacher
				case 'cache':
					$mResult = new \X2Mail\Mail\Cache\Drivers\File(
						\trim($this->oConfig->Get('cache', 'path', '')) ?: APP_PRIVATE_DATA . 'cache'
					);
					break;
*/
			}
		}

		// Always give the file provider as last for identities, it is the override
		if ('identities' === $sName) {
			$mResult[] = new Providers\Identities\FileIdentities($this->LocalStorageProvider());
		}

		foreach (\is_array($mResult) ? $mResult : array($mResult) as $oItem) {
			if ($oItem && \method_exists($oItem, 'SetLogger')) {
				$oItem->SetLogger($this->oLogger);
			}
		}

		$this->oPlugins->RunHook('filter.fabrica', array($sName, &$mResult, $oAccount), false);

		return $mResult;
	}

	public function BootEnd(): void
	{
/*
		try {
			if (!\X2Mail\Engine\Shutdown::count() && $this->ImapClient()->IsLoggined()) {
				$this->ImapClient()->Disconnect();
			}
		} catch (\Throwable $oException) {
			unset($oException);
		}
*/
	}

	protected function compileLogParams(string $sLine, ?Model\Account $oAccount = null, array $aAdditionalParams = array()): string
	{
		$aClear = array();

		if (false !== \strpos($sLine, '{date:')) {
			$oConfig = $this->oConfig;
			$sLine = \preg_replace_callback('/\{date:([^}]+)\}/', function ($aMatch) use ($oConfig) {
				return (new \DateTime('now', new \DateTimeZone($oConfig->Get('logs', 'time_zone', 'UTC'))))->format($aMatch[1]);
			}, $sLine);

			$aClear['/\{date:([^}]*)\}/'] = 'date';
		}

		if (false !== \strpos($sLine, '{imap:') || false !== \strpos($sLine, '{smtp:')) {
			if (!$oAccount) {
				$oAccount = $this->getAccountFromToken(false);
			}

			if ($oAccount) {
				$sLine = \str_replace('{imap:login}', $oAccount->ImapUser(), $sLine);
				$sLine = \str_replace('{smtp:login}', $oAccount->SmtpUser(), $sLine);
				$oDomain = $oAccount->Domain();
				if ($oDomain) {
					$sLine = \str_replace('{imap:host}', $oDomain->ImapSettings()->host, $sLine);
					$sLine = \str_replace('{imap:port}', $oDomain->ImapSettings()->port, $sLine);
					$sLine = \str_replace('{smtp:host}', $oDomain->SmtpSettings()->host, $sLine);
					$sLine = \str_replace('{smtp:port}', $oDomain->SmtpSettings()->port, $sLine);
				}
			}

			$aClear['/\{imap:([^}]*)\}/i'] = 'imap';
			$aClear['/\{smtp:([^}]*)\}/i'] = 'smtp';
		}

		if (false !== \strpos($sLine, '{request:')) {
			if (false !== \strpos($sLine, '{request:ip}')) {
				$sLine = \str_replace('{request:ip}',
					$this->Http()->GetClientIp($this->oConfig->Get('labs', 'http_client_ip_check_proxy', false)),
					$sLine);
			}

			if (false !== \strpos($sLine, '{request:domain}')) {
				$sLine = \str_replace('{request:domain}', $this->Http()->GetHost(true, true), $sLine);
			}

			if (false !== \strpos($sLine, '{request:domain-clear}')) {
				$sLine = \str_replace('{request:domain-clear}',
					\X2Mail\Mail\Base\Utils::GetClearDomainName($this->Http()->GetHost(true, true)),
					$sLine);
			}

			$aClear['/\{request:([^}]*)\}/i'] = 'request';
		}

		if (false !== \strpos($sLine, '{user:')) {
			if (false !== \strpos($sLine, '{user:uid}')) {
				$sLine = \str_replace('{user:uid}',
					\base_convert(\sprintf('%u', \crc32(Utils::GetConnectionToken())), 10, 32),
					$sLine
				);
			}

			if (false !== \strpos($sLine, '{user:ip}')) {
				$sLine = \str_replace('{user:ip}',
					$this->Http()->GetClientIp($this->oConfig->Get('labs', 'http_client_ip_check_proxy', false)),
					$sLine);
			}

			if (\preg_match('/\{user:(email|login|domain)\}/i', $sLine)) {
				if (!$oAccount) {
					$oAccount = $this->getAccountFromToken(false);
				}

				if ($oAccount) {
					$sEmail = $oAccount->Email();

					$sLine = \str_replace('{user:email}', $sEmail, $sLine);
					$sLine = \str_replace('{user:login}', \X2Mail\Mail\Base\Utils::getEmailAddressLocalPart($sEmail), $sLine);
					$sLine = \str_replace('{user:domain}', \X2Mail\Mail\Base\Utils::getEmailAddressDomain($sEmail), $sLine);
					$sLine = \str_replace('{user:domain-clear}',
						\X2Mail\Mail\Base\Utils::GetClearDomainName(\X2Mail\Mail\Base\Utils::getEmailAddressDomain($sEmail)),
						$sLine);
				}
			}

			$aClear['/\{user:([^}]*)\}/i'] = 'unknown';
		}

		if (false !== \strpos($sLine, '{labs:')) {
			$sLine = \preg_replace_callback('/\{labs:rand:([1-9])\}/', function ($aMatch) {
				return \rand(\pow(10, $aMatch[1] - 1), \pow(10, $aMatch[1]) - 1);
			}, $sLine);

			$aClear['/\{labs:([^}]*)\}/'] = 'labs';
		}

		foreach ($aAdditionalParams as $sKey => $sValue) {
			$sLine = \str_replace($sKey, $sValue, $sLine);
		}

		foreach ($aClear as $sKey => $sValue) {
			$sLine = \preg_replace($sKey, $sValue, $sLine);
		}

		return $sLine;
	}

	protected function compileLogFileName(string $sFileName): string
	{
		$sFileName = \trim($sFileName);

		if (\strlen($sFileName)) {
			$sFileName = $this->compileLogParams($sFileName);

			$sFileName = \preg_replace('/[\/]+/', '/', \preg_replace('/[.]+/', '.', $sFileName));
			$sFileName = \preg_replace('/[^a-zA-Z0-9@_+=\-\.\/!()\[\]]/', '', $sFileName);
		}

		if (!\strlen($sFileName)) {
			$sFileName = 'x2mail-log.txt';
		}

		return $sFileName;
	}

	/**
	 * @throws \X2Mail\Engine\Exceptions\ClientException
	 */
	public function GetAccount(bool $bThrowExceptionOnFalse = false): ?Model\Account
	{
		return $this->getAccountFromToken($bThrowExceptionOnFalse);
	}

	public function Http(): \X2Mail\Mail\Base\Http
	{
		if (null === $this->oHttp) {
			$this->oHttp = \X2Mail\Mail\Base\Http::SingletonInstance();
		}

		return $this->oHttp;
	}

	public function MailClient(): \X2Mail\Mail\Client\MailClient
	{
		if (null === $this->oMailClient) {
			$this->oMailClient = new \X2Mail\Mail\Client\MailClient();
			$this->oMailClient->SetLogger($this->oLogger);
		}

		return $this->oMailClient;
	}

	public function ImapClient(): \X2Mail\Mail\Imap\ImapClient
	{
//		$this->initMailClientConnection();
		return $this->MailClient()->ImapClient();
	}

	// Stores data in AdditionalAccount else MainAccount
	public function LocalStorageProvider(): Providers\Storage
	{
		if (!$this->oLocalStorageProvider) {
			$this->oLocalStorageProvider = new Providers\Storage($this->fabrica('storage-local'));
		}
		return $this->oLocalStorageProvider;
	}

	// Stores data in MainAccount
	public function StorageProvider(): Providers\Storage
	{
		if (!$this->oStorageProvider) {
			$this->oStorageProvider = new Providers\Storage($this->fabrica('storage'));
		}
		return $this->oStorageProvider;
	}

	public function SettingsProvider(bool $bLocal = false): Providers\Settings
	{
		if ($bLocal) {
			if (null === $this->oLocalSettingsProvider) {
				$this->oLocalSettingsProvider = new Providers\Settings(
					$this->fabrica('settings-local'));
			}

			return $this->oLocalSettingsProvider;
		} else {
			if (null === $this->oSettingsProvider) {
				$this->oSettingsProvider = new Providers\Settings(
					$this->fabrica('settings'));
			}

			return $this->oSettingsProvider;
		}
	}

	public function FilesProvider(): Providers\Files
	{
		if (null === $this->oFilesProvider) {
			$this->oFilesProvider = new Providers\Files(
				$this->fabrica('files'));
		}

		return $this->oFilesProvider;
	}

	public function DomainProvider(): Providers\Domain
	{
		if (null === $this->oDomainProvider) {
			$this->oDomainProvider = new Providers\Domain(
				$this->fabrica('domain'), $this->oPlugins);
		}

		return $this->oDomainProvider;
	}

	/**
	 * bForceFile is only used by admin session token
	 */
	public function Cacher(?Model\Account $oAccount = null, bool $bForceFile = false): \X2Mail\Mail\Cache\CacheClient
	{
		$sKey = '';
		if ($oAccount) {
			$sKey = $this->GetMainEmail($oAccount);
		}

		$sIndexKey = empty($sKey) ? '_default_' : $sKey;
		if ($bForceFile) {
			$sIndexKey .= '/_files_';
		}

		if (!isset($this->aCachers[$sIndexKey])) {
			$this->aCachers[$sIndexKey] = new \X2Mail\Mail\Cache\CacheClient();

			$oDriver = $bForceFile ? null : $this->fabrica('cache');
			if (!($oDriver instanceof \X2Mail\Mail\Cache\DriverInterface)) {
				$oDriver = new \X2Mail\Mail\Cache\Drivers\File(
					\trim($this->oConfig->Get('cache', 'path', '')) ?: APP_PRIVATE_DATA . 'cache'
				);
			}
			$oDriver->setPrefix($sKey);

			$this->aCachers[$sIndexKey]->SetDriver($oDriver);
			$this->aCachers[$sIndexKey]->SetCacheIndex($this->oConfig->Get('cache', 'fast_cache_index', ''));
		}

		return $this->aCachers[$sIndexKey];
	}

	public function Plugins(): Plugins\Manager
	{
		return $this->oPlugins;
	}

	protected function LoggerAuthHelper(?Model\Account $oAccount, string $sLogin = '', bool $admin = false): void
	{
		if ($sLogin) {
			$sHost = $admin ? $this->Http()->GetHost(true, true) : \X2Mail\Mail\Base\Utils::getEmailAddressDomain($sLogin);
			$aAdditionalParams = array(
				'{imap:login}' => $sLogin,
				'{imap:host}' => $sHost,
				'{smtp:login}' => $sLogin,
				'{smtp:host}' => $sHost,
				'{user:email}' => $sLogin,
				'{user:login}' => $admin ? $sLogin : \X2Mail\Mail\Base\Utils::getEmailAddressLocalPart($sLogin),
				'{user:domain}' => $sHost,
			);
		} else {
			$aAdditionalParams = array();
		}
		$sLine = $this->oConfig->Get('logs', 'auth_logging_format', '');
		if (!empty($sLine)) {
			if (!$this->oLoggerAuth) {
				$this->oLoggerAuth = new \X2Mail\Mail\Log\Logger(false);
				if ($this->oConfig->Get('logs', 'auth_logging', false)) {
//					$this->oLoggerAuth->SetLevel(\LOG_WARNING);

					$sAuthLogFileFullPath = (\trim($this->oConfig->Get('logs', 'path', '') ?: \APP_PRIVATE_DATA . 'logs'))
						. '/' . $this->compileLogFileName($this->oConfig->Get('logs', 'auth_logging_filename', ''));
					$sLogFileDir = \dirname($sAuthLogFileFullPath);
					\is_dir($sLogFileDir) || \mkdir($sLogFileDir, 0755, true);
					$this->oLoggerAuth->append(
						(new \X2Mail\Mail\Log\Drivers\File($sAuthLogFileFullPath))
							->DisableTimePrefix()
							->DisableGuidPrefix()
							->DisableTypedPrefix()
					);
				}
			}
			$this->oLoggerAuth->Write($this->compileLogParams($sLine, $oAccount, $aAdditionalParams), \LOG_WARNING);
		}
		if (($this->oConfig->Get('logs', 'auth_logging', false) || $this->oConfig->Get('logs', 'auth_syslog', false))
		 && \openlog('x2mail', 0, \LOG_AUTHPRIV)) {
			\syslog(\LOG_ERR, $this->compileLogParams(
				$admin ? 'Admin Auth failed: ip={request:ip} user={user:login}' : 'Auth failed: ip={request:ip} user={imap:login}',
				$oAccount, $aAdditionalParams
			));
			\closelog();
		}
	}

	public function AppData(bool $bAdmin): array
	{
		$oAccount = null;
		$oConfig = $this->oConfig;

		$aResult = array(
			'Auth' => false,
			'title' => $oConfig->Get('webmail', 'title', 'X2Mail'),
			'loadingDescription' => $oConfig->Get('webmail', 'loading_description', 'X2Mail'),
			'Plugins' => array(),
			'System' => array(
				'version' => APP_VERSION,
				'token' => Utils::GetCsrfToken(),
				'languages' => \X2Mail\Engine\L10n::getLanguages(false),
				'webPath' => \X2Mail\Engine\Utils::WebPath(),
				'webVersionPath' => \X2Mail\Engine\Utils::WebVersionPath()
			),
		);

		$oAccount = $this->getAccountFromToken(false);
		if ($oAccount) {
				$aResult = \array_merge(
					$aResult,
					[
						'Auth' => true,
							'allowSpellcheck' => $oConfig->Get('defaults', 'allow_spellcheck', false),
						'ViewHTML' => (bool) $oConfig->Get('defaults', 'view_html', true),
						'ViewImages' => $oConfig->Get('defaults', 'view_images', 'ask'),
						'ViewImagesWhitelist' => '',
						'RemoveColors' => (bool) $oConfig->Get('defaults', 'remove_colors', false),
						'AllowStyles' => false,
						'ListInlineAttachments' => false,
						'CollapseBlockquotes' => $oConfig->Get('defaults', 'collapse_blockquotes', true),
						'MaxBlockquotesLevel' => 0,
						'simpleAttachmentsList' => false,
						'listGrouped' => $oConfig->Get('defaults', 'mail_list_grouped', false),
						'MessagesPerPage' => \max(10, \intval($oConfig->Get('webmail', 'messages_per_page', 25)) ?: 25),
						'messageNewWindow' => false,
						'markdown' => false,
						'messageReadAuto' => true, // (bool) $oConfig->Get('webmail', 'message_read_auto', true),
						'MessageReadDelay' => (int) $oConfig->Get('webmail', 'message_read_delay', 5),
						'MsgDefaultAction' => (int) $oConfig->Get('defaults', 'msg_default_action', 1),
						'SoundNotification' => true,
						'NotificationSound' => 'new-mail',
						'DesktopNotifications' => true,
						'Layout' => (int) $oConfig->Get('defaults', 'view_layout', Enumerations\Layout::SIDE_PREVIEW->value),
						'EditorDefaultType' => \str_replace('Forced', '', $oConfig->Get('defaults', 'view_editor_type', '')),
						'editorWysiwyg' => 'Squire',
						'UseCheckboxesInList' => (bool) $oConfig->Get('defaults', 'view_use_checkboxes', true),
						'showNextMessage' => (bool) $oConfig->Get('defaults', 'view_show_next_message', false),
						'AutoLogout' => (int) $oConfig->Get('defaults', 'autologout', 30),
						'keyPassForget' => 15,
						'AllowDraftAutosave' => (bool) $oConfig->Get('defaults', 'allow_draft_autosave', true),
						'ContactsAutosave' => (bool) $oConfig->Get('defaults', 'contacts_autosave', true)
					],
					// MainAccount or AdditionalAccount
					$this->getAccountData($oAccount)
				);

				$aAttachmentsActions = array();
				if ($this->GetCapa(Capa::ATTACHMENTS_ACTIONS->value)) {
					if (\class_exists('PharData') || \class_exists('ZipArchive')) {
						$aAttachmentsActions[] = 'zip';
					}
				}
				$aResult['System'] = \array_merge(
					$aResult['System'], array(
						'allowAppendMessage' => (bool)$oConfig->Get('labs', 'allow_message_append', false),
						'folderSpecLimit' => (int)$oConfig->Get('labs', 'folders_spec_limit', 50),
						'listPermanentFiltered' => '' !== \trim($oConfig->Get('imap', 'message_list_permanent_filter', '')),
						'attachmentsActions' => $aAttachmentsActions,
					)
				);

				$sToken = \X2Mail\Engine\Cookies::get(self::AUTH_MAILTO_TOKEN_KEY);
				if (null !== $sToken) {
					\X2Mail\Engine\Cookies::clear(self::AUTH_MAILTO_TOKEN_KEY);

					$mMailToData = Utils::DecodeKeyValuesQ($sToken);
					if (!empty($mMailToData['MailTo']) && 'MailTo' === $mMailToData['MailTo'] && !empty($mMailToData['To'])) {
						$aResult['mailToEmail'] = \X2Mail\Engine\IDN::emailToUtf8($mMailToData['To']);
					}
				}

				// MainAccount
				$oSettings = $this->SettingsProvider()->Load($oAccount);
				if ($oSettings instanceof Settings) {
/*
					foreach ($oSettings->toArray() as $key => $value) {
						$aResult[\lcfirst($key)] = $value;
					}
*/
					$aResult['hourCycle'] = $oSettings->GetConf('hourCycle', '');

					if (!$oSettings->GetConf('MessagesPerPage')) {
						$oSettings->SetConf('MessagesPerPage', $oSettings->GetConf('MPP', $aResult['MessagesPerPage']));
					}

					$aResult['EditorDefaultType'] = \str_replace('Forced', '', $oSettings->GetConf('EditorDefaultType', $aResult['EditorDefaultType']));
					$aResult['editorWysiwyg'] = $oSettings->GetConf('editorWysiwyg', $aResult['editorWysiwyg']);
					$aResult['requestReadReceipt'] = (bool) $oSettings->GetConf('requestReadReceipt', false);
					$aResult['requestDsn'] = (bool) $oSettings->GetConf('requestDsn', false);
					$aResult['requireTLS'] = (bool) $oSettings->GetConf('requireTLS', false);
					$aResult['pgpSign'] = (bool) $oSettings->GetConf('pgpSign', false);
					$aResult['pgpEncrypt'] = (bool) $oSettings->GetConf('pgpEncrypt', false);
					$aResult['allowSpellcheck'] = (bool) $oSettings->GetConf('allowSpellcheck', $aResult['allowSpellcheck']);
//					$aResult['allowCtrlEnterOnCompose'] = (bool) $oSettings->GetConf('allowCtrlEnterOnCompose', true);

					$aResult['ViewHTML'] = (bool)$oSettings->GetConf('ViewHTML', $aResult['ViewHTML']);
					$show_images = (bool) $oSettings->GetConf('ShowImages', false);
					$aResult['ViewImages'] = $oSettings->GetConf('ViewImages', $show_images ? 'always' : $aResult['ViewImages']);
					$aResult['ViewImagesWhitelist'] = $oSettings->GetConf('ViewImagesWhitelist', '');
					$aResult['RemoveColors'] = (bool)$oSettings->GetConf('RemoveColors', $aResult['RemoveColors']);
					$aResult['AllowStyles'] = (bool)$oSettings->GetConf('AllowStyles', $aResult['AllowStyles']);
					$aResult['ListInlineAttachments'] = (bool)$oSettings->GetConf('ListInlineAttachments', $aResult['ListInlineAttachments']);
					$aResult['CollapseBlockquotes'] = (bool)$oSettings->GetConf('CollapseBlockquotes', $aResult['CollapseBlockquotes']);
					$aResult['MaxBlockquotesLevel'] = (int)$oSettings->GetConf('MaxBlockquotesLevel', $aResult['MaxBlockquotesLevel']);
					$aResult['simpleAttachmentsList'] = (bool)$oSettings->GetConf('simpleAttachmentsList', $aResult['simpleAttachmentsList']);
					$aResult['listGrouped'] = (bool)$oSettings->GetConf('listGrouped', $aResult['listGrouped']);
					$aResult['ContactsAutosave'] = (bool)$oSettings->GetConf('ContactsAutosave', $aResult['ContactsAutosave']);
					$aResult['MessagesPerPage'] = \max(10, \intval($oSettings->GetConf('MessagesPerPage', $aResult['MessagesPerPage']) ?: $aResult['MessagesPerPage']));
					$aResult['messageNewWindow'] = (bool)$oSettings->GetConf('messageNewWindow', $aResult['messageNewWindow']);
					$aResult['markdown'] = (bool)$oSettings->GetConf('markdown', $aResult['markdown']);
					$aResult['messageReadAuto'] = (int)$oSettings->GetConf('messageReadAuto', $aResult['messageReadAuto']);
					$aResult['MessageReadDelay'] = (int)$oSettings->GetConf('MessageReadDelay', $aResult['MessageReadDelay']);
					$aResult['MsgDefaultAction'] = (int)$oSettings->GetConf('MsgDefaultAction', $aResult['MsgDefaultAction']);
					$aResult['SoundNotification'] = (bool)$oSettings->GetConf('SoundNotification', $aResult['SoundNotification']);
					$aResult['NotificationSound'] = (string)$oSettings->GetConf('NotificationSound', $aResult['NotificationSound']);
					$aResult['DesktopNotifications'] = (bool)$oSettings->GetConf('DesktopNotifications', $aResult['DesktopNotifications']);
					$aResult['UseCheckboxesInList'] = (bool)$oSettings->GetConf('UseCheckboxesInList', $aResult['UseCheckboxesInList']);
					$aResult['showNextMessage'] = (bool)$oSettings->GetConf('showNextMessage', $aResult['showNextMessage']);
					$aResult['AllowDraftAutosave'] = (bool)$oSettings->GetConf('AllowDraftAutosave', $aResult['AllowDraftAutosave']);
					$aResult['AutoLogout'] = (int)$oSettings->GetConf('AutoLogout', $aResult['AutoLogout']);
					$aResult['keyPassForget'] = (int)$oSettings->GetConf('keyPassForget', $aResult['keyPassForget']);
					$aResult['Layout'] = (int)$oSettings->GetConf('Layout', $aResult['Layout']);
					$aResult['Resizer4Width'] = (int)$oSettings->GetConf('Resizer4Width', 0);
					$aResult['Resizer5Width'] = (int)$oSettings->GetConf('Resizer5Width', 0);
					$aResult['Resizer5Height'] = (int)$oSettings->GetConf('Resizer5Height', 0);

					$aResult['fontSansSerif'] = $oSettings->GetConf('fontSansSerif', '');
					$aResult['fontSerif'] = $oSettings->GetConf('fontSerif', '');
					$aResult['fontMono'] = $oSettings->GetConf('fontMono', '');

					if ($this->GetCapa(Capa::USER_BACKGROUND->value)) {
						$aResult['userBackgroundName'] = (string)$oSettings->GetConf('UserBackgroundName', '');
						$aResult['userBackgroundHash'] = (string)$oSettings->GetConf('UserBackgroundHash', '');
					}
				}

				$aResult['newMailSounds'] = [];
				foreach (\glob(APP_VERSION_ROOT_PATH.'static/sounds/*.mp3') as $file) {
					$aResult['newMailSounds'][] = \basename($file, '.mp3');
				}
//				foreach (\glob(APP_INDEX_ROOT_PATH.'notifications/*.mp3') as $file) {
//					$aResult['newMailSounds'][] = 'custom@'.\basename($file, '.mp3');
//				}
			}

		if ($aResult['Auth']) {
			$aResult['proxyExternalImages'] = (bool)$oConfig->Get('labs', 'use_local_proxy_for_external_images', false);
			$aResult['autoVerifySignatures'] = (bool)$oConfig->Get('security', 'auto_verify_signatures', false);
			$aResult['allowLanguagesOnSettings'] = (bool) $oConfig->Get('webmail', 'allow_languages_on_settings', true);
			$aResult['minRefreshInterval'] = (int) $oConfig->Get('webmail', 'min_refresh_interval', 5);
			$aResult['Capa'] = $this->Capa($bAdmin, $oAccount);
			$value = \ini_get('upload_max_filesize');
			$upload_max_filesize = \intval($value);
			switch (\strtoupper(\substr($value, -1))) {
				case 'G': $upload_max_filesize *= 1024;
				case 'M': $upload_max_filesize *= 1024;
				case 'K': $upload_max_filesize *= 1024;
			}
			$aResult['attachmentLimit'] = \min($upload_max_filesize, ((int) $oConfig->Get('webmail', 'attachment_size_limit', 10)) * 1024 * 1024);
			$aResult['phpUploadSizes'] = array(
				'upload_max_filesize' => $value,
				'post_max_size' => \ini_get('post_max_size')
			);
			$aResult['System']['themes'] = $this->GetThemes();
		}

		$aResult['Theme'] = $this->GetTheme($bAdmin);

		$aResult['language'] = $this->GetLanguage();
		$aResult['clientLanguage'] = $this->ValidateLanguage($this->detectClientLanguage($bAdmin), '', false, true);

		$aResult['PluginsLink'] = $this->oPlugins->HaveJs($bAdmin)
			? 'Plugins/0/' . ($bAdmin ? 'Admin' : 'User') . '/' . $this->etag($this->oPlugins->Hash()) . '/'
			: '';

		$aResult['StaticLibsJs'] = Utils::WebStaticPath('js/libs.js');

		$this->oPlugins->InitAppData($bAdmin, $aResult, $oAccount);

		return $aResult;
	}

	protected function loginErrorDelay(): void
	{
		$iDelay = (int) $this->oConfig->Get('login', 'fault_delay', 0);
		if (0 < $iDelay) {
			$seconds = $iDelay - (\microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']);
			if (0 < $seconds) {
				\usleep(\intval($seconds * 1000000));
			}
		}
	}

	public function DoPing(): array
	{
		return $this->DefaultResponse('Pong');
	}

	public function DoVersion(): array
	{
		return $this->DefaultResponse(APP_VERSION === (string)$this->GetActionParam('version', ''));
	}

	public function Upload(?array $aFile, int $iError): array
	{
		$oAccount = $this->getAccountFromToken();

		$aResponse = array();

		if ($oAccount && UPLOAD_ERR_OK === $iError && \is_array($aFile)) {
			$sSavedName = 'upload-post-' . \md5($aFile['name'] . $aFile['tmp_name']);

			// Detect content-type
			$type = \X2Mail\Engine\File\MimeType::fromFile($aFile['tmp_name'], $aFile['name'])
				?: \X2Mail\Engine\File\MimeType::fromFilename($aFile['name']);
			if ($type) {
				$aFile['type'] = $type;
				$sSavedName .= \X2Mail\Engine\File\MimeType::toExtension($type);
			}

			if (!$this->FilesProvider()->MoveUploadedFile($oAccount, $sSavedName, $aFile['tmp_name'])) {
				$iError = Enumerations\UploadError::ON_SAVING->value;
			} else {
				$aResponse['Attachment'] = array(
					'name' => $aFile['name'],
					'tempName' => $sSavedName,
					'mimeType' => $aFile['type'],
					'size' => (int) $aFile['size']
				);
			}
		}

		if (UPLOAD_ERR_OK !== $iError) {
			$iClientError = 0;
			$sError = Enumerations\UploadError::getUserMessage($iError, $iClientError);

			if (!empty($sError)) {
				$aResponse['code'] = $iClientError;
				$aResponse['Error'] = $sError;
			}
		}

		return $this->DefaultResponse($aResponse);
	}

	public function Capa(bool $bAdmin, ?Model\Account $oAccount = null): array
	{
		static $aResult;
		if (!$aResult) {
			$oConfig = $this->oConfig;
			$aResult = array(
				Capa::ADDITIONAL_ACCOUNTS->value   => (bool) $oConfig->Get('webmail', 'allow_additional_accounts', false),
				Capa::ATTACHMENT_THUMBNAILS->value => (bool) $oConfig->Get('interface', 'show_attachment_thumbnail', true)
					&& ($bAdmin
						|| \extension_loaded('gd')
						|| \extension_loaded('gmagick')
						|| \extension_loaded('imagick')
					),
				Capa::ATTACHMENTS_ACTIONS->value => (bool) $oConfig->Get('capa', 'attachments_actions', false),
				Capa::CONTACTS->value            => (bool) $oConfig->Get('contacts', 'enable', false),
				Capa::DANGEROUS_ACTIONS->value   => (bool) $oConfig->Get('capa', 'dangerous_actions', true),
				Capa::GNUPG->value               => (bool) $oConfig->Get('security', 'gnupg', true) && \X2Mail\Engine\PGP\GnuPG::isSupported(),
				Capa::IDENTITIES->value          => (bool) $oConfig->Get('webmail', 'allow_additional_identities', false),
				Capa::OPENPGP->value             => (bool) $oConfig->Get('security', 'openpgp', true),
				Capa::SIEVE->value               => false,
				Capa::THEMES->value              => (bool) $oConfig->Get('webmail', 'allow_themes', false),
				Capa::USER_BACKGROUND->value     => (bool) $oConfig->Get('webmail', 'allow_user_background', false),
				'Kolab'                   => false, // See Kolab plugin
			);
		}
		$aResult[Capa::SIEVE->value] = $bAdmin || ($oAccount && $oAccount->Domain()->SieveSettings()->enabled);
		return $aResult;
	}

	public function GetCapa(string $sName, ?Model\Account $oAccount = null): bool
	{
		return !empty($this->Capa(false, $oAccount)[$sName]);
	}

	public function etag(string $sKey): string
	{
//		if ($sKey && $this->oConfig->Get('cache', 'enable', true) && $this->oConfig->Get('cache', 'http', true)) {
		return \md5($sKey . $this->oConfig->Get('cache', 'index', '') . APP_VERSION);
	}

	public function cacheByKey(string $sKey): bool
	{
		if ($sKey && $this->oConfig->Get('cache', 'enable', true) && $this->oConfig->Get('cache', 'http', true)) {
			\X2Mail\Mail\Base\Http::ServerUseCache(
				$this->etag($sKey),
				0, // issue with messages
				$this->oConfig->Get('cache', 'http_expires', 3600)
			);
			return true;
		}
		$this->Http()->ServerNoCache();
		return false;
	}

	public function verifyCacheByKey(string $sKey): void
	{
		if ($sKey && $this->oConfig->Get('cache', 'enable', true) && $this->oConfig->Get('cache', 'http', true)) {
			\X2Mail\Mail\Base\Http::checkETag($this->etag($sKey));
//			\X2Mail\Mail\Base\Http::checkLastModified(0);
		}
	}

	/**
	 * @throws \X2Mail\Engine\Exceptions\ClientException
	 */
	protected function initMailClientConnection(): ?Model\Account
	{
		$oAccount = $this->getAccountFromToken();

		if ($oAccount && !$this->ImapClient()->IsLoggined()) {
			try {
				$oAccount->ImapConnectAndLogin($this->oPlugins, $this->ImapClient(), $this->oConfig);
			} catch (\X2Mail\Mail\Net\Exceptions\ConnectionException $oException) {
				throw new Exceptions\ClientException(Notifications::ConnectionError->value, $oException);
			} catch (\Throwable $oException) {
				throw new Exceptions\ClientException(Notifications::AuthError->value, $oException);
			}
		}

		return $oAccount;
	}

	public function encodeRawKey(array $aValues): string
	{
		$aValues['accountHash'] = $this->getAccountFromToken()->Hash();
		return \X2Mail\Mail\Base\Utils::UrlSafeBase64Encode(\json_encode($aValues));
	}

	public function decodeRawKey(string $sRawKey): array
	{
		return empty($sRawKey) ? []
			: (\json_decode(\X2Mail\Mail\Base\Utils::UrlSafeBase64Decode($sRawKey), true) ?: []);
/*
		if (empty($aValues['accountHash']) || $aValues['accountHash'] !== $oAccount->Hash()) {
			return [];
		}
*/
	}

	public function SetActionParams(array $aCurrentActionParams, string $sMethodName = ''): self
	{
		$this->oPlugins->RunHook('filter.action-params', array($sMethodName, &$aCurrentActionParams));

		$this->aCurrentActionParams = $aCurrentActionParams;

		return $this;
	}

	/**
	 * @param mixed $mDefault = null
	 *
	 * @return mixed
	 */
	public function GetActionParam(string $sKey, $mDefault = null)
	{
		return isset($this->aCurrentActionParams[$sKey]) ?
			$this->aCurrentActionParams[$sKey] : $mDefault;
	}

	public function GetActionParams(): array
	{
		return $this->aCurrentActionParams;
	}

	public function HasActionParam(string $sKey): bool
	{
		return isset($this->aCurrentActionParams[$sKey]);
	}

	public function Location(string $sUrl, int $iStatus = 302): void
	{
		$this->logWrite("{$iStatus} Location: {$sUrl}");
		\X2Mail\Mail\Base\Http::Location($sUrl, $iStatus);
	}

}
