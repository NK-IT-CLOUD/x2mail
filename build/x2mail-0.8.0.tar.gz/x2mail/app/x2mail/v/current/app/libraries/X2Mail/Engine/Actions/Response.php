<?php

namespace X2Mail\Engine\Actions;

use X2Mail\Engine\Notifications;
use X2Mail\Engine\Utils;

trait Response
{
	/**
	 * @param mixed $mResult
	 */
	public function DefaultResponse($mResult, array $aAdditionalParams = array(), string $sActionName = '') : array
	{
		if (false === $mResult) {
			if (!isset($aAdditionalParams['code'])) {
				$aAdditionalParams['code'] = 0;
			}
			if (!isset($aAdditionalParams['message'])) {
				$aAdditionalParams['message'] = '';
			}
		}

		return \array_merge(array(
//			'version' => APP_VERSION,
			'Action' => $sActionName,
			'Result' => $this->responseObject($mResult)
		), $aAdditionalParams);
	}

	public function TrueResponse(array $aAdditionalParams = array()) : array
	{
		return $this->DefaultResponse(true, $aAdditionalParams);
	}

	public function FalseResponse(int $iErrorCode = 0, string $sErrorMessage = '', string $sAdditionalErrorMessage = '') : array
	{
		return $this->DefaultResponse(false, [
			'code' => $iErrorCode,
			'message' => $sErrorMessage,
			'messageAdditional' => $sAdditionalErrorMessage
		]);
	}

	public function ExceptionResponse(\Throwable $oException) : array
	{
		$iErrorCode = Notifications::UnknownError->value;
		$sErrorMessage = $oException->getMessage();
		$sErrorMessageAdditional = '';
		$iExceptionCode = 0;

		if ($oException instanceof \X2Mail\Engine\Exceptions\ClientException) {
			$iErrorCode = $oException->getCode();
			if ($iErrorCode === Notifications::ClientViewError->value) {
				$sErrorMessage = $oException->getMessage();
			}
			$sErrorMessageAdditional = $oException->getAdditionalMessage();
		} else {
			$iExceptionCode = $oException->getCode();
		}

		$this->logException($oException->getPrevious() ?: $oException);

		return $this->DefaultResponse(false, [
			'code' => $iErrorCode,
			'message' => $sErrorMessage,
			'messageAdditional' => $sErrorMessageAdditional,
			'ExceptionCode' => $iExceptionCode
		]);
	}

	/**
	 * @param mixed $mResponse
	 *
	 * @return mixed
	 */
	private $aCheckableFolder = null;
	private function responseObject($mResponse, string $sParent = '')
	{
		if (!($mResponse instanceof \JsonSerializable)) {
			if (\is_object($mResponse)) {
				return '["'.\get_class($mResponse).'"]';
			}

			if (\is_array($mResponse)) {
				foreach ($mResponse as $iKey => $oItem) {
					$mResponse[$iKey] = $this->responseObject($oItem, 'Array');
				}
			}

			return $mResponse;
		}

		if ($mResponse instanceof \X2Mail\Mail\Client\Message) {
			$aResult = $mResponse->jsonSerialize();
			if (!$sParent && \strlen($aResult['readReceipt']) && !\in_array('$mdnsent', $aResult['flags']) && !\in_array('\\answered', $aResult['flags'])) {
				$oAccount = $this->getAccountFromToken();
				if ('1' === $this->Cacher($oAccount)->Get(\X2Mail\Engine\KeyPathHelper::ReadReceiptCache($oAccount->Email(), $aResult['folder'], $aResult['uid']), '0')) {
					$aResult['readReceipt'] = '';
				}
			}
			return $aResult;
		}

		if ($mResponse instanceof \X2Mail\Mail\Imap\Folder) {
			$aResult = $mResponse->jsonSerialize();

			if (null === $this->aCheckableFolder) {
				$aCheckable = \json_decode(
					$this->SettingsProvider(true)
					->Load($this->getAccountFromToken())
					->GetConf('CheckableFolder', '[]')
				);
				$this->aCheckableFolder = \is_array($aCheckable) ? $aCheckable : array();
			}
			$aResult['checkable'] = \in_array($mResponse->FullName, $this->aCheckableFolder);

			return $aResult;
		}

		return $mResponse;
	}
}
