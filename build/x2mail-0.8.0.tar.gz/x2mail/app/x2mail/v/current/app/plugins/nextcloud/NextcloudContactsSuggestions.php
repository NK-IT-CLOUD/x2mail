<?php

class NextcloudContactsSuggestions implements \X2Mail\Engine\Providers\Suggestions\ISuggestions
{
	use \X2Mail\Mail\Log\Inherit;

	private bool $ignoreSystemAddressbook;

	function __construct(bool $ignoreSystemAddressbook = true)
	{
		$this->ignoreSystemAddressbook = $ignoreSystemAddressbook;
	}

	public function Process(\X2Mail\Engine\Model\Account $oAccount, string $sQuery, int $iLimit = 20): array
	{
		try
		{
			$sQuery = \trim($sQuery);
			if ('' === $sQuery) {
				return [];
			}

			$cm = \OC::$server->getContactsManager();
			if (!$cm || !$cm->isEnabled()) {
				return [];
			}

			// Unregister system addressbook so as to return only contacts in user's addressbooks
			if ($this->ignoreSystemAddressbook) {
				foreach($cm->getUserAddressBooks() as $addressBook) {
					if($addressBook->isSystemAddressBook()) {
						 $cm->unregisterAddressBook($addressBook);
					}
				}
			}

			$aSearchResult = $cm->search($sQuery, array('FN', 'NICKNAME', 'TITLE', 'EMAIL'));

			//$this->oLogger->WriteDump($aSearchResult);

			if (\is_array($aSearchResult) && 0 < \count($aSearchResult)) {
				$iInputLimit = $iLimit;
				$aResult = array();
				foreach ($aSearchResult as $aContact) {
					if (0 >= $iLimit) {
						break;
					}
					if (!empty($aContact['UID'])) {
						$sUid = $aContact['UID'];
						$mEmails = isset($aContact['EMAIL']) ? $aContact['EMAIL'] : '';

						$sFullName = isset($aContact['FN']) ? \trim($aContact['FN']) : '';
						if (empty($sFullName) && isset($aContact['NICKNAME'])) {
							$sFullName = \trim($aContact['NICKNAME']);
						}

						if (!\is_array($mEmails)) {
							$mEmails = array($mEmails);
						}

						foreach ($mEmails as $sEmail) {
							$sHash = $sFullName.'|'.$sEmail;
							if (!isset($aResult[$sHash])) {
								$aResult[$sHash] = array($sEmail, $sFullName);
								--$iLimit;
							}
						}
					}
				}
				return \array_slice(\array_values($aResult), 0, $iInputLimit);
			}
		}
		catch (\Exception $oException)
		{
			$this->logException($oException);
		}

		return [];
	}
}
