<?php

/*
 * This file is part of MailSo.
 *
 * (c) 2014 Usenko Timur
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace X2Mail\Mail\Log\Drivers;

/**
 * @category MailSo
 * @package Log
 * @subpackage Drivers
 */
class File extends \X2Mail\Mail\Log\Driver
{
	private string $sLoggerFileName;

	function __construct(string $sLoggerFileName)
	{
		parent::__construct();

		$sLogFileDir = \dirname($sLoggerFileName);
		if (!\is_dir($sLogFileDir)) {
			\mkdir($sLogFileDir, 0755, true);
		}
		$this->sLoggerFileName = $sLoggerFileName;
	}

	protected function writeImplementation($mDesc) : bool
	{
		if (\is_array($mDesc)) {
			$mDesc = \implode("\n\t", $mDesc);
		}
		return \error_log($mDesc . "\n", 3, $this->sLoggerFileName);
	}

	protected function clearImplementation() : bool
	{
		return \unlink($this->sLoggerFileName);
	}
}
