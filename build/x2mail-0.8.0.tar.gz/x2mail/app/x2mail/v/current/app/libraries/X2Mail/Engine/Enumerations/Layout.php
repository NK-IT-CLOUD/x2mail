<?php

namespace X2Mail\Engine\Enumerations;

enum Layout: int
{
	case NO_PREVIEW = 0;
	case SIDE_PREVIEW = 1;
	case BOTTOM_PREVIEW = 2;
}
